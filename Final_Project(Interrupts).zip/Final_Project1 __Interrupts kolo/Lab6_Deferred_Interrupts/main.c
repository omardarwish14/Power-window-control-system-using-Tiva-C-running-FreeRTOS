#include <stdint.h>
#include <string.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <semphr.h>
#include "tm4c123gh6pm.h"

#define PortA_IRQn 0 //jamming highest priority
#define PortB_IRQn 1 //Lock second highest priority
#define PortF_IRQn 30 //MOTOR
#define PortE_IRQn 4 //Driver 4th highest priority
#define PortD_IRQn 3 //passenger lowest priority,LIMIT SWITCHES

/*Allowance values
#define DRIVER_AUTO_UP_BUTTON 1
#define DRIVER_AUTO_DOWN_BUTTON 1
#define PASSENGER_AUTO_UP_BUTTON 1
#define PASSENGER_AUTO_DOWN_BUTTON 1
#define DRIVER_MAN_UP_BUTTON 2
#define DRIVER_MAN_DOWN_BUTTON 2
#define PASSENGER_MAN_UP_BUTTON 2
#define PASSENGER_MAN_DOWN_BUTTON 2
#define JAMMING_BUTTON 3
*/

/******** cw-> downwards ****** ccw-> upwards *******/
typedef enum
	{
		cw = 1 ,ccw = 2
  }DIRECTION;
typedef enum
{
up,down
}WINDOW;
typedef enum
{
driverManualUp,driverManualDown,driverAutoUp,driverAutoDown,driverLock
,PassengerManualUp,PassengerManualDown,PassengerAutoUp,PassengerAutoDown
,Jamming	
}BUTTONS;

char flag_Auto = 0;
char tick = 0;
char flag_Man_Pressed = 0;
char allowance = 0;



void vApplicationIdleHook();


void vApplicationIdleHook()
{
	while(1)
	{
	}
}

void PortA_Init(void);
void PortB_Init(void);
void PortF_Init(void);
void PortE_Init(void);
void PortD_Init(void);
void motor_Init(void);
void motor_On(DIRECTION x);
void motor_Off(void);
void ls_Init(WINDOW x);
void Button_Init(BUTTONS x);
void TIMER0_START(void);
void TIMER0_Stop(void);

//define a Semaphore handle
xSemaphoreHandle xBinarySemaphore;
xSemaphoreHandle SemaphoreManual;
xSemaphoreHandle SemaphoreAutomatic;
xSemaphoreHandle SemaphoreJamming;

void Initiate(void *pvParameters)
{
	PortA_Init();
	PortB_Init();
	PortF_Init();
	PortD_Init();
	PortE_Init();
	motor_Init();
	ls_Init(up);
	ls_Init(down);
	Button_Init(driverManualUp);
	Button_Init(driverManualDown);
	Button_Init(driverAutoUp);
	Button_Init(driverAutoDown);
	Button_Init(driverLock);
	Button_Init(PassengerManualUp);
	Button_Init(PassengerManualDown);
	Button_Init(PassengerAutoUp);
	Button_Init(PassengerAutoDown);
	Button_Init(Jamming);
  while(1)
	{
		vTaskDelete(NULL);
	}
}

void Automatic(void *pvParameters)
{
const char *pcTaskName = "Task driver is running\n";
xSemaphoreTake( SemaphoreAutomatic, 0 );	
for( ;; )
{
  xSemaphoreTake( SemaphoreAutomatic, portMAX_DELAY );
	char value_LS_Down = (GPIOD->DATA & 0x01);
	char value_LS_Up   = (GPIOD->DATA & 0x02) >> 1;
 if	((flag_Auto == 1)) //driver automatic down
 {	 
  while((value_LS_Down == 0x01))	 
	{
		motor_On(cw);
	}
	}
 else if ((flag_Auto == 2))//driver automatic up
{  
	while((value_LS_Up == 0x01))	 
	{
		motor_On(ccw);
	}
}	 
 else if ((flag_Auto == 3))//passenger automatic up
 {
	 while((value_LS_Up == 0x01))	 
	{
		motor_On(ccw);
	}
 }
 else if ((flag_Auto == 4))//passenger automatic down
 {
	 while((value_LS_Down == 0x01))	 
	{
		motor_On(cw);
	}
 }
else 
	{
   motor_Off();
  }
}	
}
	
void JAMMING(void *pvParameters)
{
	xSemaphoreTake( SemaphoreJamming, 0 );
	for(;;)
	{
		char value_DriverAutoUp = (GPIOE->DATA & (0x08))>>3;
		if(value_DriverAutoUp == 0x00)
		{
		xSemaphoreTake( SemaphoreJamming, portMAX_DELAY );
		}
		TIMER0_START();
		switch(tick)
		{
			case 0:
			motor_On(cw);	
			break;
      case 1:
      motor_Off();	
			break;
      default:
      break;				
		}
	}
}

void Manual(void *pvParameters)
{
	xSemaphoreTake( SemaphoreManual, 0 );
	for(;;)
	{
		xSemaphoreTake( SemaphoreManual, portMAX_DELAY );
		char value_LS_Down = (GPIOD->DATA & 0x01);
	    char value_LS_Up   = (GPIOD->DATA & 0x02) >> 1;
		
		while((flag_Man_Pressed == 1) && (value_LS_Down == 0x01)) //driver manual down
		{
      motor_On(cw);
		}		
    while((flag_Man_Pressed == 2) && (value_LS_Up == 0x01)) //driver manual up
		{
      motor_On(ccw);
		}					
			while((flag_Man_Pressed == 3) && (value_LS_Up == 0x01)) //passenger manual up
		{
      motor_On(ccw);
		}			
			while((flag_Man_Pressed == 4) && (value_LS_Down == 0x01)) //passenger manual down
		{
      motor_On(cw);
		}			
		
		
		
	}
}

void Handler(void *pvParameters)
{
	xSemaphoreTake(xBinarySemaphore,0);
	for(;;)
	{
			xSemaphoreTake(xBinarySemaphore,portMAX_DELAY);
		  switch(allowance)
			{
				case 1:
				xSemaphoreGive(SemaphoreAutomatic);	
				break;
				case 2:
				xSemaphoreGive(SemaphoreManual);
        break;
        case 3:				
				xSemaphoreGive(SemaphoreJamming);	
				break;
				default:
				break;
			}
  }
}

//This Periodic task is preempted by the task "Handler"


                         /*main function*/
/*------------------------------------------------------------------------*/
int main( void )
{
		__ASM("CPSIE i");
		
		vSemaphoreCreateBinary(xBinarySemaphore);
	  vSemaphoreCreateBinary(SemaphoreManual);
    vSemaphoreCreateBinary(SemaphoreAutomatic);	
		vSemaphoreCreateBinary(SemaphoreJamming);
	
		//xBinarySemaphore = xSemaphoreCreateBinary();
	if( xBinarySemaphore != NULL )
		{
			xTaskCreate(Initiate, "Initiate", 240, NULL, 4, NULL );
		  xTaskCreate(JAMMING, "JAMMING", 240, NULL, 2, NULL );
		  xTaskCreate(Automatic, "Automatic", 240, NULL, 1, NULL );
			xTaskCreate(Manual, "Manual", 240, NULL, 1, NULL );
			xTaskCreate(Handler, "Handler", 240, NULL, 3, NULL );
			/* Create the task that will periodically generate a software interrupt.
			This is created with a priority below the handler task to ensure it will
			get preempted each time the handler task exits the Blocked state. */
		//	xTaskCreate( vPeriodicTask, "Periodic", 240, NULL, 1, NULL );
			/* Start the scheduler so the created tasks start executing. */
			vTaskStartScheduler();
		}

    /* If all is well we will never reach here as the scheduler will now be
    running the tasks.  If we do reach here then it is likely that there was
    insufficient heap memory available for a resource to be created. */
    for( ;; );
		return 0;
}

/*-------------------------------PORT INITS-----------------------------------------*/
//Initialize the hardware of Port-F
void PortA_Init(void){ 
  SYSCTL->RCGCGPIO |= 0x00000001;    // 1) A clock

	while((SYSCTL->PRGPIO & 0x01) == 0){}
  GPIOA->LOCK = 0x4C4F434B;  				 // 2) unlock Porta Pa0  
  GPIOA->CR = 0x04;          				 // allow changes to Pa2       
  GPIOA->AMSEL= 0x00;       				 // 3) disable analog function
  GPIOA->PCTL = 0x00000000;  				 // 4) GPIO clear bit PCTL  
  GPIOA->DIR = 0x00;         				 // 5) PORTA INPUT   
  GPIOA->AFSEL = 0x00;      				 // 6) no alternate function
  GPIOA->PUR = 0x04;       				   // enable pulldown resistors on PF4,PF0       
  GPIOA->DEN = 0x04;       				   // 7) enable digital pins PF4-PF0
	GPIOA->DATA = 0x00;
	
	// Setup the interrupt on PortF
	GPIOA->ICR = 0x04;     // Clear any Previous Interrupt 
	GPIOA->IM |=0x04;      // Unmask the interrupts for PF0 and PF4
	GPIOA->IS |= 0x00;     // Make bits PF0 and PF4 level sensitive
	GPIOA->IEV |= 0x00;   // Sense on Low Level
  
	
	NVIC_EN0_R = 0x01;
	NVIC_PRI7_R = 0xe0; // 
}
void PortB_Init(void){ 
  SYSCTL->RCGCGPIO |= 0x00000002;    // 1) B clock
	while((SYSCTL->PRGPIO & 0x02) == 0){}
  GPIOB->LOCK = 0x4C4F434B;  				 // 2) unlock Porta Pa0  
  GPIOB->CR = 0x04;          				 // allow changes to Pa2       
  GPIOB->AMSEL= 0x00;       				 // 3) disable analog function
  GPIOB->PCTL = 0x00000000;  				 // 4) GPIO clear bit PCTL  
  GPIOB->DIR = 0x00;         				 // 5) PORTA INPUT   
  GPIOB->AFSEL = 0x00;      				 // 6) no alternate function
  GPIOB->PUR = 0x04;       				   // enable pulldown resistors on PF4,PF0       
  GPIOB->DEN = 0x04;       				   // 7) enable digital pins PF4-PF0
	GPIOB->DATA = 0x00;
	
	// Setup the interrupt on PortF
	GPIOB->ICR = 0x04;     // Clear any Previous Interrupt 
	GPIOB->IM |=0x04;      // Unmask the interrupts for PF0 and PF4
	GPIOB->IS |= 0x00;     // Make bits PF0 and PF4 level sensitive
	GPIOB->IEV |= 0x00;   // Falling edge
  GPIOB->IBE = (GPIOB->IBE & 0xFB) | (0x04);

	NVIC_EnableIRQ(PortB_IRQn);        // Enable the Interrupt for PortA in NVIC
  NVIC->IP[PortB_IRQn] = 4 << 5;
}
void PortF_Init(void){ 
  SYSCTL->RCGCGPIO |= 0x00000020;    // 1) C clock
  GPIOF->LOCK = 0x4C4F434B;  				 // 2) unlock Porta Pa0  
  GPIOF->CR = 0x11;          				 // allow changes to Pa2       
  GPIOF->AMSEL= 0x00;       				 // 3) disable analog function
  GPIOF->PCTL = 0x00000000;  				 // 4) GPIO clear bit PCTL  
  GPIOF->DIR = 0x00;         				 // 5) PORTA INPUT   
  GPIOF->AFSEL = 0x00;      				 // 6) no alternate function
  GPIOF->PUR = 0x11;       				   // enable pulldown resistors on PF4,PF0       
  GPIOF->DEN = 0x11;       				   // 7) enable digital pins PF4-PF0
	GPIOF->DATA = 0x00;
	
	// Setup the interrupt on PortF
	GPIOF->ICR = 0x00;     // Clear any Previous Interrupt 
	GPIOF->IM |=0x00;      // Unmask the interrupts for PF0 and PF4
	GPIOF->IS |= 0x00;     // Make bits PF0 and PF4 level sensitive
	GPIOF->IEV |= 0x00;   //  Falling edge
  

/*	NVIC_EnableIRQ(Port_FIRQn);        // Enable the Interrupt for PortA in NVIC
  NVIC->IP[PortC_IRQn] = 5 << 5; */
}
void PortD_Init(void){ 
  SYSCTL->RCGCGPIO |= 0x00000008;    // 1) D clock
	while((SYSCTL->PRGPIO & 0x08) == 0){}
  GPIOD->LOCK = 0x4C4F434B;  				 // 2) unlock Porta Pa0  
  GPIOD->CR = 0xF;          				 // allow changes to Pa2       
  GPIOD->AMSEL= 0x00;       				 // 3) disable analog function
  GPIOD->PCTL = 0x00000000;  				 // 4) GPIO clear bit PCTL  
  GPIOD->DIR = 0x00;         				 // 5) PORTA INPUT   
  GPIOD->AFSEL = 0x00;      				 // 6) no alternate function
  GPIOD->PUR = 0xFF;       				   // enable pulldown resistors on PF4,PF0       
  GPIOD->DEN = 0xFF;       				   // 7) enable digital pins PF4-PF0
	GPIOD->DATA = 0x00;
	
	// Setup the interrupt on PortD
	GPIOD->ICR = 0xCC	;     // Clear any Previous Interrupt 
	GPIOD->IM |=0xCC;      // Unmask the interrupts for PF0 and PF4
	GPIOD->IS  = (GPIOD->IS & 0xBB);     // edge sensitive
	GPIOD->IEV = (GPIOD->IEV & 0xBB) | (0x00);   // Falling edge
  GPIOD->IBE = (GPIOD->IBE & 0x77) | (0x88);   // BOTH EDGES

	NVIC_EN0_R |= 0X8;       // Enable the Interrupt for PortD in NVIC
	NVIC_PRI0_R |= 0xe0000000;//(0<<5)|(1<<6)|(1<<7)
}
void PortE_Init(void){ 
  SYSCTL->RCGCGPIO |= 0x00000010;    // 1) E clock
	while((SYSCTL->PRGPIO & 0x10) == 0){}
  GPIOE->LOCK = 0x4C4F434B;  				 // 2) unlock PortF PF0  
  GPIOE->CR = 0x1E;          				 // allow changes to PF4-0       
  GPIOE->AMSEL= 0x00;       				 // 3) disable analog function
  GPIOE->PCTL = 0x00000000;  				 // 4) GPIO clear bit PCTL  
  GPIOE->DIR = 0x00;         				 // 5) PF4,PF0 input, PF3,PF2,PF1 output   
  GPIOE->AFSEL = 0x00;      				 // 6) no alternate function
  GPIOE->PUR = 0x1E;       				   // enable pulldown resistors on PE3,PE2,PE1,PE0       
  GPIOE->DEN = 0x1E;       				   // 7) enable digital pins PF4-PF0
	GPIOE->DATA = 0x00;
	
	// Setup the interrupt on PortE
	GPIOE->ICR = 0x1E;     // Clear any Previous Interrupt 
	GPIOE->IM |=0x1E;      // Unmask the interrupts for PF0 and PF4
	GPIOE->IS = (GPIOE->IS & 0xE7)|(0x00);     // Make bits PF0 and PF4 edge sensitive
	GPIOE->IEV = (GPIOE->IEV & 0xE7) | (0x00);   // Falling edge
  GPIOE->IBE = (GPIOE->IBE & 0xF9) | (0x06);   // BOTH EDGES

	NVIC_EnableIRQ(PortE_IRQn);        // Enable the Interrupt for PortF in NVIC
  NVIC->IP[PortE_IRQn] = 7 << 5;
}


/*--------------------------------INTERRUPT HANDLERS----------------------------------------*/
//Port-A handler//Jamming Interrupt
void GPIOA_MY_Handler(void)
	{
 uint32_t i;
 if (GPIOA->MIS & 0x04)
	{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	    
		  allowance = 3;
	//Give the semaphore to the Task named handler
      xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	     
	    GPIOA->ICR = 0x04;        // clear the interrupt flag of PORTA
      i= GPIOA->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
	}
}
void GPIOB_MY_Handler(void){
uint32_t i;
if (GPIOB->MIS & 0x04)
{	 uint32_t pinLevel = GPIOB->DATA & 0x04;

    if (pinLevel)
    {
       GPIOD->IM |=0x00;// Rising edge interrupt
       NVIC_DisableIRQ(PortD_IRQn);// Handle the rising edge interrupt
    }
    else
    {
       GPIOD->IM |=0xCC; // Falling edge interrupt
       NVIC_EnableIRQ(PortD_IRQn); // Handle the falling edge interrupt
    }
	//portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	//Give the semaphore to the Task named handler
	// Reading the register to force the flag to be cleare
	//Give the semaphore to the Task named handler
	GPIOB->ICR = 0x04;        // clear the interrupt flag of PORTF
  i= GPIOB->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	//portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}	
}
void GPIOD_MY_Handler(void){
uint32_t i;
if(GPIOD->MIS & 0x04)
{
	flag_Auto = 4;
	allowance = 1;
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	//Give the semaphore to the Task named handler
  xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	
	GPIOD->ICR = 0x04;        // clear the interrupt flag of PORTF
  i= GPIOD->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
else if(GPIOD->MIS & 0x08){
 {	    // Read the pin's level to determine the edge
    uint32_t pinLevel = GPIOE->DATA & 0x08;
    
    if (pinLevel)
    {
      flag_Man_Pressed = 0;  // Rising edge interrupt
        // Handle the rising edge interrupt
    }
    else
    {
        flag_Man_Pressed =4; // Falling edge interrupt
        // Handle the falling edge interrupt
    }
		allowance = 2;
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	//Give the semaphore to the Task named handler
  xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	
	GPIOD->ICR = 0x08;       // clear the interrupt flag of PORTF
  i= GPIOD->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
 }
else if(GPIOD->MIS & 0x40)
{	
  portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	flag_Auto = 3;
	allowance = 1;
	//Give the semaphore to the Task named handler
  xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	
	GPIOD->ICR = 0x40;       // clear the interrupt flag of PORTF
  i= GPIOD->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
else if(GPIOD->MIS & 0x80)
{ 	    // Read the pin's level to determine the edge
    uint32_t pinLevel = GPIOE->DATA & 0x80;

    if (pinLevel)
    {
      flag_Man_Pressed = 0;  // Rising edge interrupt
                             // Handle the rising edge interrupt
    }
    else
    {
       flag_Man_Pressed =3;  // Falling edge interrupt
                              // Handle the falling edge interrupt
    }
		allowance = 2;
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	//Give the semaphore to the Task named handler
  xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	
	GPIOD->ICR = 0x80;       // clear the interrupt flag of PORTF
  i= GPIOD->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
//GPIOD->ICR =1;
}
void GPIOE_MY_Handler(void){
uint32_t i;
 if(GPIOE->MIS & 0x02)
 {	    // Read the pin's level to determine the edge
    uint32_t pinLevel = GPIOE->DATA & 0x02;

    if (pinLevel)
    {
      flag_Man_Pressed = 0;  // Rising edge interrupt
        // Handle the rising edge interrupt
    }
    else
    {
       flag_Man_Pressed = 2; // Falling edge interrupt
        // Handle the falling edge interrupt
    }
		allowance = 2;
	 portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	//Give the semaphore to the Task named handler
      xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	
	    GPIOE->ICR = 0x02;        // clear the interrupt flag of PORTF
      i= GPIOE->ICR ;           // Reading the register to force the flag to be cleared
		  portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
	}
 	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */

else if(GPIOE->MIS & 0x04)
 {  // Read the pin's level to determine the edge
    uint32_t pinLevel = GPIOE->DATA & 0x04;

    if (pinLevel)
    {
        flag_Man_Pressed = 0;// Rising edge interrupt
        // Handle the rising edge interrupt
    }
    else
    {
       flag_Man_Pressed = 1; // Falling edge interrupt
        // Handle the falling edge interrupt
    }
		allowance = 2;
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	//Give the semaphore to the Task named handler
    xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	
	GPIOE->ICR = 0x04;        // clear the interrupt flag of PORTF
      i= GPIOE->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
else if(GPIOE->MIS & 0x08)
 {
	flag_Auto = 2;
	allowance = 1;
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	//Give the semaphore to the Task named handler
    xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	
	 GPIOE->ICR = 0x08;        // clear the interrupt flag of PORTF
       i= GPIOE->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
else if(GPIOE->MIS & 0x10)
 {
   flag_Auto = 1;
   allowance = 1;	 
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	//Give the semaphore to the Task named handler
    xSemaphoreGiveFromISR(xBinarySemaphore,&xHigherPriorityTaskWoken);
	
	GPIOE->ICR = 0x10;        // clear the interrupt flag of PORTF
    i= GPIOE->ICR ;           // Reading the register to force the flag to be cleared

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.
	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports. The portEND_SWITCHING_ISR() macro is provided as part of
	the Corte M3 port layer for this purpose. taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
 //GPIOE->ICR =1;
}
/*
void TIMER0_Handler(void)
{
	tick = 1;
	TIMER0->ICR = 1;
}
*/
/****************************************************************/
void motor_Init(void)
{
		 GPIOF->DIR = 0x03;
	     GPIOF->CR =  0x03;
	     GPIOF->DEN = 0x03;
}
/****************************************************************/
void motor_On(DIRECTION x)
{
 /* if(x == cw)
  {
		GPIOF->DATA = 0x01;//pD0 on,pD1 off
	}		
  else
		    {
		        GPIOF->DATA = 0x02;//pD1 on,pD0 off
		    }*/
	GPIOF->DATA = (GPIOF->DATA & 0xFC) | (x);

}
/****************************************************************/
void motor_Off(void)
{
	GPIOF->DATA = 0x00;
}
/****************************************************************/
void ls_Init(WINDOW x)
{ 
	if(x == up)
	  {  
		   GPIOD->DIR = 0x00;//clear pc4(input)
	     GPIOD->CR = 0x02;//set pc4
	     GPIOD->DEN = 0x02;//set pc4
       GPIOD->PUR = 0x02;//set pc4
		}
  else
	{
		   GPIOD->DIR = 0x00;//clear pc5(input)
	     GPIOD->CR = 0x01;//set pc5
	     GPIOD->DEN = 0x01;//set pc5
       GPIOD->PUR = 0x01;//set pc5
	}		
}	
/****************************************************************/
void Button_Init(BUTTONS x)
{
switch(x)
{
	case driverManualUp:
		   GPIOE->DIR = 0x00;//clear pe1(input)
	     GPIOE->CR = 0x02;//set pe1
	     GPIOE->DEN = 0x02;//set pe1
       GPIOE->PUR = 0x02;//set pe1
	break;
	case driverManualDown:
       GPIOE->DIR = 0x00;//clear pe2(input)
	     GPIOE->CR = 0x04;//set pe2
	     GPIOE->DEN = 0x04;//set pe2
       GPIOE->PUR = 0x04;//set pe2
	break;
	case driverAutoUp:
       GPIOE->DIR = 0x00;//clear pe3(input)
	     GPIOE->CR = 0x08;//set pe3
	     GPIOE->DEN = 0x08;//set pe3
       GPIOE->PUR = 0x08;//set pe3
	break;
	case driverAutoDown:
       GPIOE->DIR = 0x00;//clear pe4(input)
	     GPIOE->CR = 0x10;//set pe4
	     GPIOE->DEN = 0x10;//set pe4
       GPIOE->PUR = 0x10;//set pe4
	break;
	case driverLock:
       GPIOB->DIR = 0x00;//clear PB2(input)
	     GPIOB->CR = 0x04;//set pb2
	     GPIOB->DEN = 0x04;//set pb2
       GPIOB->PUR = 0x04;//set pb2
	break;
	case PassengerAutoDown:
       GPIOD->DIR = 0x00;//clear PD2(input)
	     GPIOD->CR = 0x04;//set pD2
	     GPIOD->DEN = 0x04;//set pD2
       GPIOD->PUR = 0x04;//set pD2
	break;
	case PassengerManualDown:
       GPIOD->DIR = 0x00;//clear PD3(input)
	     GPIOD->CR = 0x08;//set pD3
	     GPIOD->DEN = 0x08;//set pD3
       GPIOD->PUR = 0x08;//set pD3
	break;
	case PassengerAutoUp:
       GPIOD->DIR = 0x00;//clear PD6(input)
	     GPIOD->CR = 0x40;//set pD6
	     GPIOD->DEN = 0x40;//set pD6
       GPIOD->PUR = 0x40;//set pD6
	break;
	case PassengerManualUp:
       GPIOD->DIR = 0x00;//clear PD7(input)
	     GPIOD->CR = 0x80;//set pD7
	     GPIOD->DEN = 0x80;//set pD7
       GPIOD->PUR = 0x80;//set pD7
	break;
	case Jamming:
		   GPIOA->DIR = 0x00;//clear PA2(input)
	     GPIOA->CR = 0x04;//set pa2
	     GPIOA->DEN = 0x04;//set pa2
       GPIOA->PUR = 0x04;//set pa2
	break;
	default:
		break;
}
}
void TIMER0_START(void)
{
	SYSCTL->RCGCTIMER |= 0x1;
	TIMER0->CTL = 0;
	TIMER0->CFG = 0X0;
	TIMER0->TAMR = 0x00000002 | 0x00000020;
	TIMER0->TAILR = (8000000 - 1);
	NVIC_SetPriority(TIMER0A_IRQn, configMAX_SYSCALL_INTERRUPT_PRIORITY); 
	NVIC_EnableIRQ(TIMER0A_IRQn);
	TIMER0->IMR |= 0x01;
	TIMER0->CTL = 1 ;
	TIMER0->ICR = 1; 
}

void TIMER0_Stop(void)
{
    TIMER0->CTL = 0; // Disable the Timer0 by Clear the ENABLE Bit 
}

